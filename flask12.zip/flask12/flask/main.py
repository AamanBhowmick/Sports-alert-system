from flask import Flask, render_template, request, session, redirect, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_mail import Mail
# from werkzeug.utils import secure_filename
# from werkzeug.security import check_password_hash
import json
# import os

with open('config.json', 'r') as c:
    params = json.load(c)["params"]

local_server = True
app = Flask(__name__)
app.secret_key = 'super-secret-key'
app.config['UPLOAD_FOLDER'] = params['upload_location']
app.config.update(
    MAIL_SERVER = 'smtp.gmail.com',
    MAIL_PORT = '465',
    MAIL_USE_SSL = True,
    MAIL_USERNAME = params['gmail-user'],
    MAIL_PASSWORD = params['gmail-password'],
)
mail = Mail(app)

if(local_server):
    app.config['SQLALCHEMY_DATABASE_URI'] = params['local_uri']
else:
    app.config['SQLALCHEMY_DATABASE_URI'] = params['prod_uri']

db = SQLAlchemy(app)

# pip install flask-sqlalchemy
# pip install mysqlclient
# pip install flask-mail
# pip install werkzeug

import requests
import time

class Members(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable = False)
    email = db.Column(db.String(40), nullable=False)
    contact = db.Column(db.Integer, nullable=False)
    year = db.Column(db.String(10), nullable=False)
    branch = db.Column(db.String(10), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    council_role = db.Column(db.String(50), nullable=True)
    password = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(100), nullable=True)

class Sport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sports_name = db.Column(db.String(80), nullable = False)
    sports_info = db.Column(db.String(300), nullable = False)
    sports_img  = db.Column(db.String(50), nullable = False)
    sports_slug = db.Column(db.String(30), nullable = False)

class Cricket(db.Model):
    cricket_id = db.Column(db.Integer, primary_key=True)
    team1 = db.Column(db.String(80), nullable = False)
    team2 = db.Column(db.String(80), nullable=False)
    score1 = db.Column(db.String(80), nullable = True)
    wicket1 = db.Column(db.String(80), nullable = True)
    score2 = db.Column(db.String(80), nullable = True)
    wicket2 = db.Column(db.String(80), nullable = True)
    over1 = db.Column(db.String(80), nullable=True)
    over2 = db.Column(db.String(80), nullable = True)
    info = db.Column(db.String(80), nullable = True)
    up_date = db.Column(db.String(80), nullable = True)
    date = db.Column(db.String(30))
    team1_players = db.Column(db.String(500), nullable=False)
    team2_players = db.Column(db.String(500), nullable=False)

class Cricket_details(db.Model):
    cricket_details_id = db.Column(db.Integer, primary_key=True)
    team1_players = db.Column(db.String(500), nullable=False)
    team2_players = db.Column(db.String(500), nullable=False)
    cricket_id = db.Column(db.Integer, foreign_key=True)

@app.route("/home", methods = ['GET', 'POST'])
def home():

    if not session.get("user"):
        return redirect("/")
    else:
        memb = Members.query.filter_by(email = session.get("user")).first()
        # for membs in memb:
        if memb.role == "Admin":
            game = Sport.query.filter_by().all()
            return render_template('adminhome.html', params = params, game = game)
        else:
            game = Sport.query.filter_by().all()
            return render_template('cards.html', params = params, game = game)

@app.route("/cricket", methods = ['GET', 'POST'])
def cricket():
    if not session.get("user"):
        return redirect("/")
    else:
        memb = Members.query.filter_by(email=session.get('user')).first()
        if memb.role == 'Viewer':
            crics1 = Cricket_details.query.filter_by().all()
            crics = Cricket.query.filter_by().all()
            return render_template('sportcricket.html', params=params, crics=crics, crics1=crics1)
        else:
            crics1 = Cricket_details.query.filter_by().all()
            crics = Cricket.query.filter_by().all()
            return render_template('sportcricketcouncil.html', params=params, crics=crics, crics1=crics1)

@app.route("/cricket/<int:cricket_id>", methods = ['GET', 'POST'])
def cricket_route(cricket_id):
    if not session.get("user"):
        return redirect("/")
    else:
        memb = Members.query.filter_by(email=session.get('user')).first()
        if memb.role == 'Viewer':
            crics = Cricket_details.query.filter_by(cricket_id = cricket_id).all()
            crics1 = Cricket.query.filter_by(cricket_id = cricket_id).all()
            return render_template('cricketdetails.html', params = params, crics = crics, crics1 = crics1)
        else:
            crics1 = Cricket.query.filter_by(cricket_id=cricket_id).all()
            for crics2 in crics1:
                team1_players = crics2.team1_players
                team2_players = crics2.team2_players
                cricket_id = crics2.cricket_id
                crics = Cricket_details.query.filter_by(cricket_id=cricket_id).all()
                return render_template('cricketdetailscouncil.html', params=params, crics=crics, crics1=crics1)
            crics = Cricket_details.query.filter_by(cricket_id=cricket_id).all()
            return render_template('cricketdetailscouncil.html', params=params, crics=crics, crics1=crics1)
        return render_template('cricketdetails.html', params = params)

@app.route("/", methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        memb = Members.query.filter_by(email = email).first()
        if memb:
            if memb.password == password and memb.role == role:
                if role == "Admin":
                    session['user'] = memb.email
                    session['role'] = memb.role
                    session['status'] = memb.status
                    game = Sport.query.filter_by().all()
                    return render_template('adminhome.html', params=params, game = game)
                else:
                    session['user'] = memb.email
                    session['role'] = memb.role
                    session['status'] = memb.status
                    game = Sport.query.filter_by().all()
                    return render_template('cards.html', params=params, game=game)
            else:
                flash('Incorrect password, try again.', 'error')
                return render_template('signin.html', params=params)
        else:
            flash('Email does not exist.', 'error')
            return render_template('signin.html', params=params)
    return render_template('signin.html', params = params)

@app.route("/signup", methods = ['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        contact = request.form.get('contact')
        year = request.form.get('year')
        branch = request.form.get('branch')
        role = "Viewer"
        council_role = request.form.get('council_role')
        password = request.form.get('password')
        re_pass = request.form.get('re_pass')
        memb = Members.query.filter_by(email=email).first()
        cont  = Members.query.filter_by(contact=contact).first()
        if memb:
            flash("Email id already exits!", "error")
            return render_template('signup.html', params=params)
        else:
            if cont:
                flash("Contact number already exits!", "error")
                return render_template('signup.html', params=params)
            else:
                if branch == 'Branch':
                    flash("Please select branch!", "error")
                    return render_template('signup.html', params=params)
                else:
                    if year == "Year":
                        flash("Please select Year!", "error")
                        return render_template('signup.html', params=params)
                    else:
                        if len(password) < 8:
                            flash("Your password is too short!", "error")
                            return render_template('signup.html', params=params)
                        else:
                            if len(password) > 20:
                                flash("Your password is too long!", "error")
                                return render_template('signup.html', params=params)
                            else:
                                if password == re_pass:
                                    sign = Members(name = name, email = email, contact = contact, year = year, branch = branch, role = role, council_role = council_role, password = password)
                                    db.session.add(sign)
                                    db.session.commit()
                                    flash("You have been Registered successfully!", "info")
                                    return render_template('signin.html', params=params)
                                else:
                                    flash('Password and Confirm Password do not match', 'error')
                                    return render_template('signup.html', params=params)
    return render_template('signup.html', params = params)

@app.route("/signupcouncil", methods = ['GET', 'POST'])
def signupc():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        contact = request.form.get('contact')
        year = request.form.get('year')
        branch = request.form.get('branch')
        role = "Council"
        status = "Active"
        council_role = request.form.get('council_role')
        password = request.form.get('password')
        re_pass = request.form.get('re_pass')
        memb = Members.query.filter_by(email=email).first()
        cont = Members.query.filter_by(contact=contact).first()
        if memb:
            flash("Email id already exits!", "error")
            return render_template('signupcouncil.html', params=params)
        else:
            if cont:
                flash("Contact number already exits!", "error")
                return render_template('signupcouncil.html', params=params)
            else:
                if branch == 'Branch':
                    flash("Please select branch!", "error")
                    return render_template('signupcouncil.html', params=params)
                else:
                    if year == "Year":
                        flash("Please select Year!", "error")
                        return render_template('signupcouncil.html', params=params)
                    else:
                        if council_role == "Council_role":
                            flash("Please Select Your Role!", "error")
                            return render_template('signupcouncil.html', params=params)
                        else:
                            if len(password) < 8:
                                flash("Your password is too short!", "error")
                                return render_template('signupcouncil.html', params=params)
                            else:
                                if len(password) > 20:
                                    flash("Your password is too long!", "error")
                                    return render_template('signupcouncil.html', params=params)
                                else:
                                    if password == re_pass:
                                        sign = Members(name = name, email = email, contact = contact, year = year, branch = branch, role = role, council_role = council_role, password = password, status = status)
                                        db.session.add(sign)
                                        db.session.commit()
                                        flash("You have been Registered successfully!", "info")
                                        return render_template('signin.html', params=params)
                                    else:
                                        flash('Password and Confirm Password do not match', 'error')
                                        return render_template('signupcouncil.html', params=params)
        # flash('Registered Successfully', 'success')
    #     return render_template('signin.html', params = params)
    return render_template('signupcouncil.html', params = params)

@app.route("/update/<int:cricket_id>", methods = ['GET', 'POST'])
def update(cricket_id):
    if not session.get("user"):
        return redirect("/")
    else:
        memb = Members.query.filter_by(email = session["user"]).first()
        if memb.status == "Active":
            if request.method == 'POST':
                score1 = request.form.get('s1')
                wicket1 = request.form.get('w1')
                over1 = request.form.get('o1')
                score2 = request.form.get('s2')
                wicket2 = request.form.get('w2')
                over2 = request.form.get('o2')
                info = request.form.get('info')
                up_date = request.form.get('updateall')
                updateit = Cricket.query.filter_by(cricket_id = cricket_id).first()
                updateit.score1 = score1
                updateit.score2 = score2
                updateit.wicket1 = wicket1
                updateit.wicket2 = wicket2
                updateit.over1 = over1
                updateit.over2 = over2
                updateit.info = info
                updateit.up_date = up_date
                db.session.commit()
                flash("Updated Successfully", "info")
                return redirect('/update/'+str(cricket_id))
            crics = Cricket_details.query.filter_by(cricket_id=cricket_id).all()
            crics1 = Cricket.query.filter_by(cricket_id=cricket_id).all()
            return render_template('update.html', params=params, crics=crics, crics1=crics1)
        else:
            crics1 = Cricket.query.filter_by(cricket_id=cricket_id).all()
            for crics2 in crics1:
                cricket_id = crics2.cricket_id
                crics = Cricket_details.query.filter_by(cricket_id=cricket_id).all()
                flash("You are not an active council member", "error")
                return render_template('cricketdetailscouncil.html', params=params, crics=crics, crics1=crics1)
            crics = Cricket_details.query.filter_by(cricket_id=cricket_id).all()
            flash("You are not an active council member", "error")
            return render_template('cricketdetailscouncil.html', params=params, crics=crics, crics1=crics1)
# @app.route("/telegram", methods = ['GET', 'POST'])
# def telegram(cricket_id):
#     ckt = Cricket.query.filter_by(cricket_id = cricket_id).first()
#
#     tel = ckt.team1 + " vs " + ckt.team2 + "\n" + ckt.score1 + " / " + ckt.wicket1 + " - (" + ckt.over1 + ")"
#     base_url = 'https://api.telegram.org/bot5371204184:AAH8jaSxtUHOKU8CcDRHulAJBKRR290o8QU/sendMessage?chat_id=-540516082&text="{}"'.format(tel)
#     requests.get(base_url)
#     time.sleep(20)

@app.route("/new_match_cricket", methods = ['GET', 'POST'])
def newcricketmatch():
    if not session.get("user"):
        return redirect("/")
    else:
        memb = Members.query.filter_by(email=session["user"]).first()
        if memb.status == "Active":
            if request.method == 'POST':
                team1 = request.form.get('t1')
                team2 = request.form.get('t2')
                team1_players = request.form.get('p1')
                team2_players = request.form.get('p2')
                date = datetime.now()

                addit1 = Cricket(team1 = team1, team2 = team2, date = date, team1_players = team1_players, team2_players = team2_players, score1 = 0, score2 = 0, wicket1 = 0, wicket2 = 0, over1 = "Yet to bat", over2 = "Yet to bat", info = "")

                # addit2 = Cricket_details()
                db.session.add(addit1)
                db.session.commit()
                addit2 = Cricket.query.filter_by(cricket_id = addit1.cricket_id).first()
                addit3 = Cricket_details(team1_players = team1_players, team2_players = team2_players, cricket_id = addit2.cricket_id)
                db.session.add(addit3)
                db.session.commit()
                # addit2 = Cricket.query.filter_by()
                # db.session.add(addit2)
                # db.session.commit()
                flash("Added successfully", "info")
                return redirect('/cricket')

            return render_template('addcricket.html', params= params)
        else:
            flash("You are not an active council member", "error")
            return render_template(('cricketdetailscouncil.html'), params = params)

@app.route("/admin_game")
def admin_game():
    if not session.get("user"):
        return redirect("/")
    else:
        game = Sport.query.filter_by().all()
        return render_template('admingame.html', params = params, game = game)

@app.route("/council_details")
def council_details():
    if not session.get("user"):
        return redirect("/")
    else:
        memb = Members.query.filter_by(role = "Council").all()
        return render_template('councilmembers.html', params = params, memb = memb)

@app.route("/delete_council/<int:id>", methods = ['GET', 'POST'])
def delete_council(id):
    if not session.get("user"):
        return redirect("/")
    else:
        if request.method == 'POST':
            status1 = "Deactive"
            status2 = "Active"
            memb = Members.query.filter_by(id = int(id)).first()
            # for membs in memb:
            if memb.status == "Active":
                memb.status = status1
                db.session.commit()
                return redirect("/council_details")
            else:
                memb.status = status2
                db.session.commit()
                return redirect("/council_details")

@app.route("/members_details")
def members_details():
    if not session.get("user"):
        return redirect("/")
    else:
        memb = Members.query.filter_by().all()
        return render_template('allmembers.html', params = params, memb = memb)

@app.route("/delete_members/<int:id>", methods = ['GET', 'POST'])
def delete_members(id):
    if not session.get("user"):
        return redirect("/")
    else:
        if request.method == 'POST':
            memb = Members.query.filter_by(id = int(id)).first()
            db.session.delete(memb)
            db.session.commit()
            flash("Removed Successfully", "info")
            return redirect("/members_details")
            # for membs in memb:
            # if memb.status == "Active":
            #     memb.status = status1
            #     db.session.commit()
            #     return redirect("/council_details")
            # else:
            #     memb.status = status2
            #     db.session.commit()
            #     return redirect("/council_details")
@app.route("/admin/cricket", methods = ['GET', 'POST'])
def admin_cricket():
    if not session.get("user"):
        return redirect("/")
    else:
        memb = Members.query.filter_by(email=session.get('user')).first()
        if memb.role == 'Admin':
            crics1 = Cricket_details.query.filter_by().all()
            crics = Cricket.query.filter_by().all()
            return render_template('sportcricketadmin.html', params=params, crics=crics, crics1=crics1)

@app.route("/cricket_delete/<int:cricket_id>", methods = ['GET', 'POST'])
def cricket_id(cricket_id):
    if not session.get("user"):
        return redirect("/")
    else:
        crics = Cricket_details.query.filter_by(cricket_id = cricket_id).first()
        db.session.delete(crics)
        db.session.commit()
        crics1 = Cricket.query.filter_by(cricket_id = cricket_id).first()
        db.session.delete(crics1)
        db.session.commit()
        flash("Deleted Successfully", "info")
        return redirect("/admin/cricket")

@app.route("/logout")
def logout():
    session.pop('user', None)
    flash("You have been logged out!", "info")
    return redirect('/')

app.run(debug = True)

@app.route("/layout")
def layout():
    return render_template('layout.html', params = params)
